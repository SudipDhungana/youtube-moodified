// Example video data with unique IDs
const videos = [
  { id: 1, title: "Escanor「AMV」For The Glory ", url: "https://www.youtube.com/embed/hs7cH3Y6EoQ" },
  { id: 2, title: "Kalo Keshma Relimai - Dinesh Dhakal (Lyrics)", url: "https://www.youtube.com/embed/UVvXK1rq3ZU" },
  { id: 3, title: "Royalty - AMV [ Anime Mix ]", url: "https://www.youtube.com/embed/3dYBziE9-cU" },
  { id: 4, title: "Naruto & Sasuke vs Momoshiki (AMV) - Fearless", url: "https://www.youtube.com/embed/sE2pYubPT8k" },
  { id: 5, title: "CJ - Whoopty (Robert Cristian & ERS Remix) | Shang Chi", url: "https://www.youtube.com/embed/hMvMYgPEhsw" },
  { id: 6, title: "Balen Vs Litl Grizl - Raw Barz (RAP BATTLE)", url: "https://www.youtube.com/embed/zek-Cgr8Mg4" },
  { id: 7, title: "5:55 : Maya (High Sessions)", url: "https://www.youtube.com/embed/mjadHUW2yMY" },
  { id: 8, title: "Stephen Sanchez, Em Beihold - Until I Found You", url: "https://www.youtube.com/embed/lU-csIO1x0E" },
  { id: 9, title: "Shiv Tandav Stotram X Aarambh Hai Prachand (Mashup)", url: "https://www.youtube.com/embed/V_EgCJgyXiM" },
  { id: 10, title: "David Guetta - Hey Mama (ERS REMIX) | Transformers", url: "https://www.youtube.com/embed/rs3bD2ZmJGo" },
  { id: 11, title: "Intu Mintu London By Dinesh DNX", url: "https://www.youtube.com/embed/f89KX9ZBypI" },
  { id: 12, title: "The Escapees「 AMV 」Welcome To The War - 7kingZ | Baki", url: "https://www.youtube.com/embed/7GM6Lmmspnw" },
  { id: 13, title: "Hrital maya", url: "https://www.youtube.com/embed/KEvXoPFi28k" },
  { id: 14, title: "Black Clover「AMV」ENEMY (Imagine Dragons)", url: "https://www.youtube.com/embed/r9l1WC312_k" },
  { id: 15, title: "Bye Bye Bye Opening Scene | DEADPOOL & WOLVERINE (2024) Movie CLIP", url: "https://www.youtube.com/embed/VHAK-gU9gi0" },
  { id: 16, title: "Bjorn Goes Into Battle One Last Time | Vikings | Prime Video", url: "https://www.youtube.com/embed/ANCAyz_U_oo" },
  { id: 17, title: "Captain Jack Sparrow", url: "https://www.youtube.com/embed/vdBEuLG21UE" },
  { id: 18, title: "Quicksilver Saves Everyone - Sweet Dreams - X-Men", url: "https://www.youtube.com/embed/ZnZqB5Z75zI" },
  { id: 19, title: "BLUESSS - LA LA LA LA (REMIX) FT. LIL BUDDHA & VTEN", url: "https://www.youtube.com/embed/aO73ukKokjI" },
  { id: 20, title: "One Direction - Night Changes", url: "https://www.youtube.com/embed/syFZfO_wfMQ" },
  { id: 21, title: "Benson Boone - Beautiful Things (Official Music Video)", url: "https://www.youtube.com/embed/Oa_RSwwpPaA" },
  { id: 22, title: "Keane - Somewhere Only We Know (Official Music Video)", url: "https://www.youtube.com/embed/Oextk-If8HQ" },
  { id: 23, title: "Owl City - Fireflies (Official Music Video)", url: "https://www.youtube.com/embed/psuRGfAaju4" },
  { id: 24, title: "Simple Plan - Untitled (Official Video)", url: "https://www.youtube.com/embed/ZQ7oqmikZDQ" },
  { id: 25, title: "BATASH~ Shashwot Khadka (Prod. by Sanjv) (Official Lyric Video)", url: "https://www.youtube.com/embed/AtoZw7o2kRo" },
  { id: 26, title: "Thomas Shelby | Gangsta's Paradise", url: "https://www.youtube.com/embed/FjuqZklHvT8" },
  { id: 27, title: "Launa K Garne | Neetesh Jung Kunwar", url: "https://www.youtube.com/embed/9IbQppLKdrg" },
  { id: 28, title: "One Piece - Do You Remember?", url: "https://www.youtube.com/embed/yQJJqM1Wk6E" },
  { id: 29, title: "I Told You So (Madara Uchiha Motivational Speech)", url: "https://www.youtube.com/embed/pjdzhIFU8_Y" },
  { id: 30, title: "「AMV」- Natural ✨", url: "https://www.youtube.com/embed/Sv0nfdkgvZM" },
  { id: 31, title: "Kyojuro Rengoku | Set Your Heart Ablaze", url: "https://www.youtube.com/embed/Dj2PCsCiznQ" },
  { id: 32, title: "Demon Slayer Infinity Castle Arc Movie Trailer: Kokushibo vs Pillars ", url: "https://www.youtube.com/embed/ub35Ibew1-o" },
  { id: 33, title: "Ancient One Powers | Doctor Strange and Avengers", url: "https://www.youtube.com/embed/3Qf3UgVPxiA" },
  { id: 34, title: "The story of Roronoa Zoro (One Piece)「AMV」- Royalty", url: "https://www.youtube.com/embed/Oppxp_oPg6k" },
  { id: 35, title: "Breakfast Time Inside Maximum Security Prison | Singapore |", url: "https://www.youtube.com/embed/zJ5ayZEQrHA" },
  { id: 35, title: "48 Hours with gold miners in the Mauritanian desert 🇲🇷", url: "https://www.youtube.com/embed/OXmH_C9KEm0" },
  { id: 35, title: "Risking Death in the Name of 'Natural Viagra' | Risky Business |", url: "https://www.youtube.com/embed/SKyoc_XkWEQ" },
  { id: 35, title: "What Happened to Maya Gogoi on Her Last Date Night?", url: "https://www.youtube.com/embed/7eooRiMg5iA" },
  { id: 35, title: "Attitude | Stand-up Comedy by Ravi Gupta", url: "https://www.youtube.com/embed/AgQ8RV3zn2A" },
  { id: 35, title: "Mystery of Yeti SOLVED! | Were they Real Animals?", url: "https://www.youtube.com/embed/CWdsqvg0wCw" },
  { id: 35, title: "TVF's Truth or Dare with Dad", url: "https://www.youtube.com/embed/tP-15bw-7og" },
  { id: 35, title: "I Met the Hyena Men 🇳🇬 in Nigeria", url: "https://www.youtube.com/embed/CRQxN__oDXY" },
  { id: 35, title: "One Day at Thiksey Monastery: Immersed in the Soul of Ladakh.", url: "https://www.youtube.com/embed/_k1W09nhaHw" },
];
function loadSuggestions(excludedVideoId) {
  const suggestionBox = document.getElementById("suggestion-box");
  suggestionBox.innerHTML = ""; // Clear previous suggestions

  // Filter out the excluded video
  const filteredVideos = videos.filter(video => video.id !== excludedVideoId);

  // Populate suggestions
  filteredVideos.forEach(video => {
    const suggestion = document.createElement("div");
    suggestion.className = "suggestion-item";
    suggestion.innerText = video.title;
    suggestion.onclick = () => playVideo(video.id, video.title, video.url);
    suggestionBox.appendChild(suggestion);
  });
}


// Populate video list dynamically
const videoList = document.getElementById('video-list');
const searchBar = document.getElementById('search-bar');

function populateVideos() {
  videoList.innerHTML = '';
  videos.forEach((video, index) => {
    const videoItem = document.createElement('div');
    videoItem.className = 'video-item';
    videoItem.innerHTML = `
      <img src="https://img.youtube.com/vi/${video.url.split('/').pop()}/0.jpg" alt="${video.title}">
      <p>${video.title}</p>
    `;
    videoItem.onclick = () => openVideo(index);
    videoList.appendChild(videoItem);
  });
}
function filterVideos() {
  const searchTerm = searchBar.value.trim().toLowerCase();
  videoList.innerHTML = ''; // Clear the video list

  // Filter videos based on the search term
  const filteredVideos = videos.filter(video =>
    video.title.toLowerCase().includes(searchTerm)
  );

  // Populate the filtered video list
  if (filteredVideos.length > 0) {
    filteredVideos.forEach((video, index) => {
      const videoItem = document.createElement('div');
      videoItem.className = 'video-item';
      videoItem.innerHTML = `
        <img src="https://img.youtube.com/vi/${video.url.split('/').pop()}/0.jpg" alt="${video.title}">
        <p> ${video.title} </p>
      `;
      videoItem.onclick = () => openVideo(index);
      videoList.appendChild(videoItem);
    });
  } else {
    // Show a message when no videos are found
    videoList.innerHTML = '<p style="color: white;">No videos found.</p>';
  }
}



// Initialize video list
filterVideos();
// Open video in second screen
function openVideo(index) {
  const screenOne = document.getElementById('screen-one');
  const screenTwo = document.getElementById('screen-two');
  const tvVideo = document.getElementById('tv-video');
  const videoTitle = document.getElementById('video-title');

  screenOne.style.display = 'none';
  screenTwo.style.display = 'flex';
  tvVideo.src = `${videos[index].url}?autoplay=1&controls=0&modestbranding=1&rel=0&fs=0&enablejsapi=1`;
  videoTitle.textContent = videos[index].title;
}

function playCustomVideo(event) {
  const urlInput = document.getElementById('url-input').value.trim();
  const tvVideo = document.getElementById('tv-video');
  const videoTitle = document.getElementById('video-title');

  if (event.key === 'Enter' || event.type === 'input') {
    try {
      const url = new URL(urlInput);
      const videoId =
        url.hostname === 'youtu.be'
          ? url.pathname.slice(1)
          : new URLSearchParams(url.search).get('v');

      if (videoId) {
        tvVideo.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&controls=0&modestbranding=1&rel=0&fs=0&enablejsapi=1`;
        document.getElementById('screen-two').style.display = 'flex';
        document.getElementById('screen-one').style.display = 'none';

        videoTitle.textContent = "Playing custom video...";
        
        // Hide all suggestions since the custom video doesn't belong to the list
        suggestionBox.innerHTML = '<p style="color: white;">Suggestions are hidden for custom videos.</p>';
      } else {
        alert('Invalid YouTube URL. Please ensure it is a valid video link.');
      }
    } catch {
      alert('Invalid URL. Please ensure it is a valid YouTube link.');
    }
  }
}

  


// Add event listeners to handle URL input change
document.getElementById('url-input').addEventListener('input', playCustomVideo);
document.getElementById('url-input').addEventListener('keydown', playCustomVideo);



const sidebar = document.getElementById('sidebar');
const container = document.querySelector('.container');

// Create overlay element for mobile view
const overlay = document.createElement('div');
overlay.className = 'overlay';
document.body.appendChild(overlay);

// Toggle Sidebar and Overlay for Mobile Screens
function toggleSidebar() {
  if (window.innerWidth <= 768) {
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
  } else {
    sidebar.classList.toggle('collapsed');
    container.classList.toggle('collapsed');
  }
}

// Hide Sidebar and Overlay when overlay is clicked
overlay.addEventListener('click', () => {
  sidebar.classList.remove('active');
  overlay.classList.remove('active');
});


// Close sidebar when clicking outside
window.addEventListener('click', (event) => {
  if (!event.target.closest('#sidebar') && !event.target.closest('.menu-btn')) {
    document.getElementById('sidebar').style.left = '0px';
  }
});

// Populate videos on load
populateVideos();
function playCustomVideo(event) {
  const urlInput = document.getElementById('url-input').value.trim();
  const tvVideo = document.getElementById('tv-video');
  if (event.key === 'Enter' || event.type === 'input') {
    try {
      const url = new URL(urlInput);
      const videoId =
        url.hostname === 'youtu.be'
          ? url.pathname.slice(1)
          : new URLSearchParams(url.search).get('v');

      if (videoId) {
        tvVideo.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&controls=0&enablejsapi=1&modestbranding=1`;
        document.getElementById('screen-two').style.display = 'flex';
        document.getElementById('screen-one').style.display = 'none';
      } else {
        alert('Invalid YouTube URL. Please ensure it is a valid video link.');
      }
    } catch {
      alert('Invalid URL. Please ensure it is a valid YouTube link.');
    }
  }
}
// Utility function to send commands to the video
function sendVideoCommand(command) {
  const video = document.getElementById('tv-video');
  if (video) {
    video.contentWindow.postMessage(
      JSON.stringify({ event: 'command', func: command, args: '' }),
      '*'
    );
  } else {
    console.error('Video element not found!');
  }
}

// Toggle play/pause functionality
function togglePlayPause() {
  const playButton = document.getElementById('play-btn');
  const pauseButton = document.getElementById('pause-btn');

  if (playButton.style.display === 'none') {
    sendVideoCommand('pauseVideo');
    playButton.style.display = 'block';
    pauseButton.style.display = 'none';
  } else {
    sendVideoCommand('playVideo');
    playButton.style.display = 'none';
    pauseButton.style.display = 'block';
  }
}

// Toggle mute/unmute functionality
function toggleMuteUnmute() {
  const muteButton = document.getElementById('mute-btn');
  const unmuteButton = document.getElementById('unmute-btn');

  if (muteButton.style.display === 'none') {
    sendVideoCommand('unMute');
    muteButton.style.display = 'block';
    unmuteButton.style.display = 'none';
  } else {
    sendVideoCommand('mute');
    muteButton.style.display = 'none';
    unmuteButton.style.display = 'block';
  }
}

// Initialize buttons and attach event listeners on page load
window.onload = function () {
  const playButton = document.getElementById('play-btn');
  const pauseButton = document.getElementById('pause-btn');
  const muteButton = document.getElementById('mute-btn');
  const unmuteButton = document.getElementById('unmute-btn');

  // Set default button states
  if (playButton && pauseButton && muteButton && unmuteButton) {
    playButton.style.display = 'none'; // Video is playing by default
    pauseButton.style.display = 'block'; // Show pause button
    muteButton.style.display = 'block'; // Video is unmuted by default
    unmuteButton.style.display = 'none'; // Hide unmute button

    // Attach event listeners
    playButton.addEventListener('click', togglePlayPause);
    pauseButton.addEventListener('click', togglePlayPause);
    muteButton.addEventListener('click', toggleMuteUnmute);
    unmuteButton.addEventListener('click', toggleMuteUnmute);
  } else {
    console.error('One or more buttons are missing!');
  }
};

const suggestionBox = document.querySelector('.suggestion-box');

// Function to populate the suggestion box with thumbnails
function populateSuggestions(excludeIndex = null) {
  suggestionBox.innerHTML = ''; // Clear any existing items

  videos.forEach((video, index) => {
    if (index === excludeIndex) return; // Exclude the currently selected video

    const videoItem = document.createElement('div');
    videoItem.classList.add('video-item');

    // Extract the video ID from the URL
    const videoId = video.url.split('/').pop();

    videoItem.innerHTML = `
      <img src="https://img.youtube.com/vi/${videoId}/0.jpg" alt="${video.title}">
      <p>${video.title}</p>
    `;

    // Play the video in the main player when the thumbnail is clicked
    videoItem.onclick = () => {
      const tvVideo = document.getElementById('tv-video');
      const videoTitle = document.getElementById('video-title');
      
      tvVideo.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&controls=0&modestbranding=1&rel=0&fs=0&enablejsapi=1`;
      videoTitle.textContent = video.title;

      document.getElementById('screen-two').style.display = 'flex';
      document.getElementById('screen-one').style.display = 'none';

      // Repopulate suggestions excluding the selected video
      populateSuggestions(index);
    };

    suggestionBox.appendChild(videoItem);
  });
}



// Call the function to populate suggestions
populateVideos();
populateSuggestions();